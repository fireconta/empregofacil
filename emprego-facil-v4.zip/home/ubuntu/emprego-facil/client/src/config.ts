export const APP_DOWNLOAD_LINK = "https://play.google.com/store/apps/details?id=com.empregofacil.app"; // Link para download do aplicativo definido aqui
export const GOOGLE_SCRIPT_URL = ""; // Cole a URL do seu Web App do Google Apps Script aqui
